typedef struct reactivo
{
    char pregunta[100];
    char opc1[100];
    char opc2[100];
    char opc3[100];
    char opCorrecta[4];
    char opUsuario[4];

} reactivo_t;

typedef struct  nodo
{
    reactivo_t  *reactivo;
    struct nodo *sig;
    struct nodo *pre;
} nodo_t;

typedef struct
{
    nodo_t *head;
    nodo_t *tail;
    int total;
    int correctas;
} lista_t;

nodo_t *crearNodo(reactivo_t *v);

lista_t *crearListaDoble();

int isEmpty(lista_t *l);

void printLista(lista_t *l);

void insertarAlInicio(lista_t *lista, reactivo_t *v);

void insertarAlFinal(lista_t *l, reactivo_t *v);

void insertarEnIndice(lista_t *l, reactivo_t *r, int indx);

void deleteEnIndice(lista_t *lista, int indx);
