/*
*	EDA I		GRUPO 13
*
*	Granados Villeda Johan Raciel
*	Chavez Pacheco Juan Alberto
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"lista_doble.h"

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

char *password = "eda";
char *nom_examen ="examen.txt";

void pausa(int pollingDelay){
//sleep:
#ifdef _WIN32
    Sleep(pollingDelay);
#else
    // unix/linux
    usleep(pollingDelay*1000);  /* sleep for 100 milliSeconds */
#endif
}

void limpiarPantalla(){
#ifdef _WIN32
    system("cls");
#else
    // unix/linux
    system("clear");
#endif
}

void esperaEnter(){
    printf("Enter para continuar...\n");
    setbuf(stdin,NULL);
    getchar();
}


float contestar(lista_t *l){
    float calificacion = 0;
    if(!isEmpty(l)){
        int c=1;
        nodo_t *aux = l->head;
        while(aux != NULL){
            printf("\n");
            printPregunta(c++, aux);
            fflush(stdin);
            scanf("%s",aux->reactivo->opUsuario);
            printf("\n\n");
            if((aux->reactivo->opCorrecta[0]) == (aux->reactivo->opUsuario[0])){
                calificacion++;
            }
            aux = aux->sig;
        }
        l->correctas=calificacion;
        calificacion= ((l->correctas)*10)/(l->total);
    }
    return calificacion;
}

lista_t *leerArchivo(char *nom_archivo){
    FILE *archivo;
    char linea[500];
    char *separador = "|\n";
    // token es un apuntador a cadena que va a indicar el inicio de cada palabra encontrada
    // y se va a modificar conforme encuentre una nueva palabra.
    char *token;
    lista_t *lista = crearListaDoble();
    archivo = fopen ( nom_archivo, "r" );
    reactivo_t *r;
    // Para cada linea leida del archivo
    while (feof(archivo) == 0)
    {
        // Leer una linea completa del archivo
        fgets(linea,sizeof(linea),archivo);
        if (feof(archivo) == 0){
            linea[strlen(linea)-1]='\0';
            token = strtok(linea,separador);

            if(token != NULL)
            {
                r = (reactivo_t*)malloc(sizeof(reactivo_t));

                strcpy(r->pregunta,token);
                token = strtok(NULL, separador);
                strcpy(r->opc1,token);

                token = strtok(NULL, separador);
                strcpy(r->opc2,token);

                token = strtok(NULL, separador);
                strcpy(r->opc3,token);

                token = strtok(NULL, separador);
                strcpy(r->opCorrecta,token);

                insertarAlFinal(lista,r);
            }
        }
    }

    fclose ( archivo );

    return lista;
}

void guardarArchivo(char *nom_archivo, lista_t *l){
    if(!isEmpty(l)){
        FILE *archivo;
        archivo = fopen ( nom_archivo, "w" );
        nodo_t *aux = l->head;
        reactivo_t *r= NULL;

        while(aux != NULL){
            r = aux->reactivo;
            fprintf(archivo,"%s|%s|%s|%s|%s\n",
                    r->pregunta, r->opc1, r->opc2, r->opc3, r->opCorrecta);
            aux = aux->sig;
        }
        fclose ( archivo );
    }
}

void mostrarExamenResps(lista_t *l){
    int c=1;
    nodo_t *aux = l->head;
    while(aux != NULL){
            printf("%d.- %s \n\n",c,aux->reactivo->pregunta);
            printf("1) %s \n",aux->reactivo->opc1);
            printf("2) %s \n",aux->reactivo->opc2);
            printf("3) %s \n",aux->reactivo->opc3);
            printf("\nRespuesta correcta : ");
            printf(" %s \n",aux->reactivo->opCorrecta);
            printf("\n\n");
            aux = aux->sig;
            c++;
        }
}

void printExamenResuelto(lista_t *l){
    float calificacion=0;
    int c=1;
    nodo_t *aux = l->head;
    while(aux != NULL){
            printf("%d.- %s \n\n",c,aux->reactivo->pregunta);
            printf("1) %s \n",aux->reactivo->opc1);
            printf("2) %s \n",aux->reactivo->opc2);
            printf("3) %s \n",aux->reactivo->opc3);
            printf("\nTu respuesta fue : ");
            printf(" %s \n",aux->reactivo->opUsuario);
            printf("\n\n");
            aux = aux->sig;
            c++;
        }
        calificacion= ((l->correctas)*10)/(l->total);
    printf(" %.2f \n",calificacion);
}

reactivo_t *leerInfo(){
	reactivo_t *r=(reactivo_t*)malloc(sizeof(reactivo_t));
	printf("\n Ingrese la pregunta: ");
	scanf( " %[^\n]",r->pregunta);
	printf("Ingrese reactivo 1: ");
	scanf( " %[^\n]",r->opc1);
	printf("Ingrese reactivo 2: ");
	scanf( " %[^\n]",r->opc2);
	printf("Ingrese reactivo 3: ");
	scanf( " %[^\n]",r->opc3);
	printf("Ingrese opcion correcta: ");
	scanf( " %[^\n]",r->opCorrecta);
	return r;
}

void printPregunta(int c, nodo_t *aux){
    printf("%d.- %s \n\n",c,aux->reactivo->pregunta);
    printf("1) %s \n",aux->reactivo->opc1);
    printf("2) %s \n",aux->reactivo->opc2);
    printf("3) %s \n",aux->reactivo->opc3);
    printf("\nRespuesta [1 ,2 ,3 ]: ");
}

void registrarPregunta(lista_t *l){
	reactivo_t *n=NULL;
	int num;
	limpiarPantalla();
	printf("\n MENU PARA REGISTRAR PREGUNTA");
    getchar();
    n=leerInfo();
    printf("En donde desea agregarla?: ");
	scanf("%i",&num);
	insertaEnIndice(l, n, num);
    guardarArchivo(nom_examen, l);
	printf("\nPregunta agregada correctamente c: \n");
    esperaEnter();
}

void mostrarPreguntas(lista_t *l){
	int c=1;
	nodo_t *aux=l->head;
	while(aux!=NULL)
	{
	printf("%d.- %s \n\n",c,aux->reactivo->pregunta);
	 aux = aux->sig;
    c++;
    }
}

void eliminarPregunta(lista_t *l)
{
    limpiarPantalla();
	printf("\n MENU PARA ELIMINAR PREGUNTA\n\n");
	int a;
    mostrarPreguntas(l);
    printf("Ingrese el numero de pregunta a eliminar: \n");
    scanf("%d",&a);
    deleteEnIndice(l,a);
    guardarArchivo(nom_examen, l);
	printf("\nPregunta borrada correctamente c:\n");
    esperaEnter();
}

int menuAlumno()
{
    int opc;
    limpiarPantalla();
    printf("\n\n\tMenu del Alumno\n\n");
    printf("1) Contestar examen\n");
    printf("2) Mostrar la revision\n");
    printf("3) Menu para el profesor\n");
    printf("4) Salir\n");
    fflush(stdin);
    scanf("%d",&opc);
    return opc;
}
int menuProfesor()
{
    int opc;
    limpiarPantalla();
    printf("\n\n\tMenu del profesor\n\n");
    printf("1) Agregar pregunta al examen\n");
    printf("2) Eliminar pregunta al examen\n");
    printf("3) Mostar examen, incluidas la respuestas\n");
    printf("4) Salir\n");
    fflush(stdin);
    scanf("%d",&opc);
    return opc;
}

void subMenuProfesor(lista_t *l)
{

    int opc, continuar=1;
    char clave[20];
    printf("Clave del submenu [%s]:",password);
    scanf("%s",clave);

    if(strcmp(password,clave)!=0)
    {
        continuar =0;
        printf("Clave incorrecta\n");
        pausa(600);
    }

    while(continuar)
    {
        opc = menuProfesor();
        switch(opc)
        {
        case 1:
            registrarPregunta(l);
            break;
        case 2:
            eliminarPregunta(l);
            break;
        case 3:
            mostrarExamenResps(l);
            esperaEnter();
            break;
        case 4:
            continuar =0;
            break;
        default:
            printf("Opcion no valida\n");
            pausa(300);
        }
    }

}

int main()
{
    int opc, continuar=1;

    lista_t *examen = leerArchivo(nom_examen);

    while(continuar)
    {
        opc = menuAlumno();
        switch(opc)
        {
        case 1:
            printf("\n\tCalificacion %.2f \n", contestar(examen) );
            esperaEnter();
            break;
        case 2:
            printExamenResuelto(examen);
            esperaEnter();
            break;
        case 3:
            subMenuProfesor(examen);
            break;
        case 4:
            continuar =0;
            break;
        default:
            printf("Opcion no valida\n");
            pausa(300);
        }
    }
    return 0;
}
