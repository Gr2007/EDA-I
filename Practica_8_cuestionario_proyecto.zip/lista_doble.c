#include<stdio.h>
#include<stdlib.h>
#include"lista_doble.h"

lista_t *crearListaDoble()
{
    lista_t *lista = malloc(sizeof(lista_t));

    lista->head = NULL;
    lista->tail  = NULL;
    lista->total =0;
    lista->correctas =0;
    return lista;
}

nodo_t *crearNodo(reactivo_t *v)
{
    nodo_t *nuevo = (nodo_t *)malloc(sizeof(nodo_t));
    nuevo->reactivo = v;
    nuevo->sig   = NULL;
    nuevo->pre   = NULL;
    return nuevo;
}

int isEmpty(lista_t *l)
{
    int regreso;
    if(l->head == NULL && l->tail == NULL)
    {
        regreso = 1;
    }
    else
    {
        regreso = 0;
    }

    return regreso;
}

void printLista(lista_t *l)
{
    if(!isEmpty(l))
    {
        int c=1;
        nodo_t *aux = l->head;
        while(aux != NULL)
        {
            printPregunta(c++, aux);
            aux = aux->sig;
        }
    }
}

void insertarAlInicio(lista_t *lista, reactivo_t *v)
{
    //nodo_t *nuevo = crearNodo(v);
    nodo_t *nuevo = (nodo_t *)malloc(sizeof(nodo_t));
    nuevo->reactivo = v;
    if(lista->head == NULL && lista->tail == NULL )
    {
        //primer elemento de l
        lista->head = nuevo;
        lista->tail = nuevo;

    }
    else
    {
        lista->head->pre = nuevo ;   //
        nuevo->sig      = lista->head;  // Enlazar el nuevo nodo
        lista->head      = nuevo;  // Recorre Head al primer nodo
    }

    lista->total++;

}

void insertarAlFinal(lista_t *lista, reactivo_t *v)
{
     nodo_t *nuevo = crearNodo(v);

    if(lista->head == NULL  && lista->tail == NULL)
    {
        //primer elemento de l
        lista->head = nuevo;
        lista->tail = nuevo;
    }
    else
    {
        lista->tail->sig = nuevo;   //
        nuevo->pre    = lista->tail;  // Enlazar el nuevo nodo
        lista->tail      = nuevo;     // Recorre Tail al ultimo nodo
    }

    lista->total++;

}

void insertaEnIndice(lista_t *lista, reactivo_t *v, int indx)
{

    nodo_t *aux = (nodo_t*)malloc(sizeof(nodo_t));

    if(indx <= lista->total )
    {

        if(indx == 1)
        {
            insertarAlInicio(lista,v);
        }
        else if(indx == lista->total)
        {
            insertarAlFinal(lista,v);
        }
        else
        {

            int i=1;
            aux = lista->head;
            while(i<indx-1)
            {
                aux = aux->sig;
                i++;
            }

            nodo_t *nuevo = crearNodo(v);

            nuevo->sig = aux->sig;
            nuevo->pre = aux;
            aux->sig = nuevo;
            nuevo->sig->pre = nuevo;

            lista->total++;

        }

    }
}


void deleteEnIndice(lista_t *lista, int indx)
{

    nodo_t *aux = NULL;

    if( (0 <= indx)  && (indx < lista->total) )
    {

        if(lista->total == 1)
        {
            free(lista->head);
            lista->head = NULL;
            lista->tail = NULL;
            lista->total--;
        }
        else if(indx == 1)
        {
            // Borrar el primer elemento
            aux  = lista->head;
            lista->head = aux->sig;
            lista->head->pre = NULL;
            free(aux);
            lista->total--;
        }
        else if(indx == (lista->total-1))
        {
            // Borrar el ultimo elemento
            aux  = lista->tail;
            lista->tail = aux->pre;
            lista->tail->sig = NULL;
            free(aux);

            lista->total--;

        }
        else
        {
            // Borrar un elemento intermedio
            int i=1;
            aux = lista->head;

            while(i<indx-1)
            {
                aux = aux->sig;
                i++;
            }

            nodo_t *liberar     = aux->sig;
            aux->sig            = liberar->sig;
            (liberar->sig)->pre = aux;
            free(liberar);
            lista->total--;

        }
    }
    else
    {
        printf("error en deleteEnIndice() indice fuera de la lista\n");
    }
}
